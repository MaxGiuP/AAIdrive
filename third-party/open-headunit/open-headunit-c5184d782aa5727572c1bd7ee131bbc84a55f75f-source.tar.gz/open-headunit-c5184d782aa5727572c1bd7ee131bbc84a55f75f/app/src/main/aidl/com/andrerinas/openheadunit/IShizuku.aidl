package com.andrerinas.openheadunit;

interface IShizuku {

    int execShell(String command, boolean asRoot);
}
